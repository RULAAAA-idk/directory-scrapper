"""Cleaning and deduplication.

Raw directory data is messy in predictable ways: phone numbers in six
formats, "Ste 4" vs "Suite 4", the same business listed twice with one
trailing space. This is the part buyers actually pay for.
"""

from __future__ import annotations

import re
import unicodedata
from collections.abc import Iterable, Iterator

from .models import Business

EMAIL_RE = re.compile(r"[\w.+-]+@[\w-]+\.[\w.-]+")
NON_DIGIT = re.compile(r"\D")
WHITESPACE = re.compile(r"\s+")

TRACKING_PARAMS = ("utm_", "fbclid", "gclid", "ref=", "mc_cid", "mc_eid")


def squash(text: str | None) -> str:
    """Collapse whitespace, normalise unicode, strip."""
    if not text:
        return ""
    text = unicodedata.normalize("NFKC", str(text))
    return WHITESPACE.sub(" ", text).strip()


def clean_phone(raw: str | None, default_country: str = "1") -> str:
    """Return E.164-ish digits, or the squashed original if it can't be parsed.

    Never throws away data it doesn't understand — an unparseable number is
    still a number the buyer can dial.
    """
    text = squash(raw)
    if not text:
        return ""

    had_plus = text.strip().startswith("+")
    digits = NON_DIGIT.sub("", text)
    if not digits:
        return ""

    if had_plus:
        return f"+{digits}"
    if len(digits) == 10 and default_country == "1":
        return f"+1{digits}"
    if len(digits) == 11 and digits.startswith("1") and default_country == "1":
        return f"+{digits}"
    if len(digits) == 10 and default_country == "91":
        return f"+91{digits}"
    if 7 <= len(digits) <= 15:
        return f"+{default_country}{digits}" if default_country else digits
    return text


def clean_email(raw: str | None) -> str:
    text = squash(raw).lower()
    if not text:
        return ""
    match = EMAIL_RE.search(text)
    return match.group(0) if match else ""


def clean_website(raw: str | None) -> str:
    """Normalise a URL and drop tracking junk from the query string."""
    text = squash(raw)
    if not text:
        return ""
    if text.startswith("//"):
        text = "https:" + text
    elif not text.startswith(("http://", "https://")):
        text = "https://" + text

    if "?" in text:
        base, _, query = text.partition("?")
        kept = [
            part
            for part in query.split("&")
            if part and not any(part.lower().startswith(p) for p in TRACKING_PARAMS)
        ]
        text = base + ("?" + "&".join(kept) if kept else "")
    return text.rstrip("/")


def clean_business(biz: Business, default_country: str = "1") -> Business:
    biz.name = squash(biz.name)
    biz.category = squash(biz.category).lower()
    biz.street = squash(biz.street)
    biz.city = squash(biz.city)
    biz.state = squash(biz.state)
    biz.postcode = squash(biz.postcode)
    biz.country = squash(biz.country)
    biz.phone = clean_phone(biz.phone, default_country)
    biz.email = clean_email(biz.email)
    biz.website = clean_website(biz.website)
    biz.rating = squash(biz.rating)
    biz.review_count = NON_DIGIT.sub("", squash(biz.review_count))
    return biz


def _dedupe_keys(biz: Business) -> list[str]:
    """Several keys per record — a match on any one means a duplicate."""
    name = re.sub(r"[^a-z0-9]", "", biz.name.lower())
    keys = []
    if biz.phone:
        keys.append(f"phone:{biz.phone}")
    if biz.website:
        host = biz.website.split("//", 1)[-1].split("/", 1)[0].lower()
        host = host[4:] if host.startswith("www.") else host
        if name:
            keys.append(f"site:{host}|{name}")
    if name and biz.street:
        street = re.sub(r"[^a-z0-9]", "", biz.street.lower())
        keys.append(f"addr:{name}|{street}")
    if name and biz.city:
        keys.append(f"city:{name}|{re.sub(r'[^a-z0-9]', '', biz.city.lower())}")
    return keys


def _merge(primary: Business, other: Business) -> Business:
    """Fill blanks on primary from other. Keeps the richer record."""
    for attr in (
        "name", "category", "street", "city", "state", "postcode", "country",
        "phone", "email", "website", "rating", "review_count",
        "latitude", "longitude", "source_url",
    ):
        if not getattr(primary, attr) and getattr(other, attr):
            setattr(primary, attr, getattr(other, attr))
    return primary


def dedupe(records: Iterable[Business]) -> list[Business]:
    """Collapse duplicates, merging their fields rather than dropping data."""
    seen: dict[str, int] = {}
    out: list[Business] = []

    for biz in records:
        keys = _dedupe_keys(biz)
        hit = next((seen[k] for k in keys if k in seen), None)
        if hit is None:
            index = len(out)
            out.append(biz)
            for key in keys:
                seen.setdefault(key, index)
        else:
            _merge(out[hit], biz)
            for key in keys:
                seen.setdefault(key, hit)
    return out


def pipeline(
    records: Iterable[Business],
    default_country: str = "1",
    drop_empty: bool = True,
) -> list[Business]:
    """Clean, drop junk rows, dedupe. The one call the CLI makes."""
    cleaned: Iterator[Business] = (
        clean_business(b, default_country) for b in records
    )
    kept = [b for b in cleaned if b.name and not (drop_empty and b.is_empty)]
    return dedupe(kept)
