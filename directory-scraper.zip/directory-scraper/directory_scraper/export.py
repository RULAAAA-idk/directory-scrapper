"""Export to the formats buyers actually open: CSV and Excel."""

from __future__ import annotations

import csv
from collections.abc import Sequence
from pathlib import Path

from .models import FIELD_ORDER, Business


def _headers(records: Sequence[Business]) -> list[str]:
    extra: list[str] = []
    for biz in records:
        for key in biz.extra:
            if key not in FIELD_ORDER and key not in extra:
                extra.append(key)
    return FIELD_ORDER + extra


def to_csv(records: Sequence[Business], path: str | Path) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    headers = _headers(records)

    with path.open("w", newline="", encoding="utf-8-sig") as fh:
        writer = csv.DictWriter(fh, fieldnames=headers, extrasaction="ignore")
        writer.writeheader()
        for biz in records:
            writer.writerow(biz.to_row())
    return path


def to_xlsx(records: Sequence[Business], path: str | Path, title: str = "Leads") -> Path:
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.utils import get_column_letter

    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    headers = _headers(records)

    wb = Workbook()
    ws = wb.active
    ws.title = title[:31]
    ws.append([h.replace("_", " ").title() for h in headers])

    header_font = Font(bold=True, color="FFFFFF")
    header_fill = PatternFill("solid", start_color="2F5597")
    for cell in ws[1]:
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = Alignment(vertical="center")

    for biz in records:
        row = biz.to_row()
        ws.append([row.get(h, "") for h in headers])

    # Width by longest cell, capped so one long URL doesn't blow out the sheet.
    for idx, header in enumerate(headers, start=1):
        longest = max(
            [len(header)] + [len(str(b.to_row().get(header, ""))) for b in records] or [10]
        )
        ws.column_dimensions[get_column_letter(idx)].width = min(max(longest + 2, 12), 45)

    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions
    wb.save(path)
    return path


def write_all(records: Sequence[Business], stem: str | Path) -> list[Path]:
    """Write <stem>.csv and <stem>.xlsx. Buyers get both, always."""
    stem = Path(stem)
    return [
        to_csv(records, stem.with_suffix(".csv")),
        to_xlsx(records, stem.with_suffix(".xlsx")),
    ]
