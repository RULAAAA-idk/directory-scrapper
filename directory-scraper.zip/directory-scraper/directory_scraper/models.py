"""Record types shared by every adapter."""

from __future__ import annotations

from dataclasses import dataclass, field, asdict, fields
from typing import Any


FIELD_ORDER = [
    "name",
    "category",
    "street",
    "city",
    "state",
    "postcode",
    "country",
    "phone",
    "email",
    "website",
    "rating",
    "review_count",
    "latitude",
    "longitude",
    "source",
    "source_url",
]


@dataclass
class Business:
    """One row of the deliverable.

    Every field is optional: directories are inconsistent, and a half-filled
    row is still worth money to a lead-gen buyer. Missing values stay as
    empty strings so the exported sheet has no 'None' noise in it.
    """

    name: str = ""
    category: str = ""
    street: str = ""
    city: str = ""
    state: str = ""
    postcode: str = ""
    country: str = ""
    phone: str = ""
    email: str = ""
    website: str = ""
    rating: str = ""
    review_count: str = ""
    latitude: str = ""
    longitude: str = ""
    source: str = ""
    source_url: str = ""
    extra: dict[str, Any] = field(default_factory=dict, repr=False)

    def to_row(self) -> dict[str, Any]:
        data = asdict(self)
        data.pop("extra", None)
        row = {key: data.get(key, "") for key in FIELD_ORDER}
        for key, value in self.extra.items():
            row.setdefault(key, value)
        return row

    @property
    def is_empty(self) -> bool:
        return not any(
            getattr(self, f.name)
            for f in fields(self)
            if f.name != "extra" and f.name not in ("source", "source_url")
        )
