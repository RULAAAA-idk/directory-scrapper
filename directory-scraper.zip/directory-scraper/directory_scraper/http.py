"""Polite HTTP layer: robots.txt checks, rate limiting, retries.

The whole value of this module is that it makes it hard to be rude to a
server by accident. Every adapter goes through PoliteSession, so rate
limiting and robots.txt compliance are not something an adapter author has
to remember.
"""

from __future__ import annotations

import logging
import random
import time
from dataclasses import dataclass
from urllib.parse import urljoin, urlparse
from urllib.robotparser import RobotFileParser

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

log = logging.getLogger(__name__)

DEFAULT_USER_AGENT = (
    "directory-scraper/1.0 (+https://github.com/USERNAME/directory-scraper; "
    "contact: YOUR-EMAIL@example.com)"
)


class RobotsDisallowed(RuntimeError):
    """Raised when robots.txt forbids the URL we were asked to fetch."""


@dataclass
class RateLimit:
    """Simple blocking rate limiter with jitter.

    delay is the minimum gap between requests, in seconds. jitter adds up to
    that many extra seconds at random so the traffic pattern isn't a metronome.
    """

    delay: float = 1.5
    jitter: float = 0.75
    _last_call: float = 0.0

    def wait(self) -> None:
        elapsed = time.monotonic() - self._last_call
        target = self.delay + random.uniform(0, self.jitter)
        if elapsed < target:
            time.sleep(target - elapsed)
        self._last_call = time.monotonic()


class PoliteSession:
    """A requests.Session that respects robots.txt and throttles itself."""

    def __init__(
        self,
        user_agent: str = DEFAULT_USER_AGENT,
        delay: float = 1.5,
        jitter: float = 0.75,
        timeout: float = 30.0,
        obey_robots: bool = True,
        max_retries: int = 3,
    ) -> None:
        self.user_agent = user_agent
        self.timeout = timeout
        self.obey_robots = obey_robots
        self.limiter = RateLimit(delay=delay, jitter=jitter)
        self._robots: dict[str, RobotFileParser | None] = {}

        retry = Retry(
            total=max_retries,
            backoff_factor=1.5,
            status_forcelist=(429, 500, 502, 503, 504),
            allowed_methods=frozenset({"GET", "HEAD"}),
            respect_retry_after_header=True,
        )
        self.session = requests.Session()
        self.session.headers.update(
            {
                "User-Agent": user_agent,
                "Accept-Language": "en-US,en;q=0.9",
            }
        )
        adapter = HTTPAdapter(max_retries=retry, pool_maxsize=4)
        self.session.mount("https://", adapter)
        self.session.mount("http://", adapter)

    # -- robots -----------------------------------------------------------

    def _robots_for(self, url: str) -> RobotFileParser | None:
        parts = urlparse(url)
        root = f"{parts.scheme}://{parts.netloc}"
        if root in self._robots:
            return self._robots[root]

        parser = RobotFileParser()
        robots_url = urljoin(root, "/robots.txt")
        try:
            resp = self.session.get(robots_url, timeout=self.timeout)
            if resp.status_code >= 400:
                # No robots.txt is not permission to hammer the site, but it
                # is not a prohibition either. Rate limiting still applies.
                parser = None
            else:
                parser.parse(resp.text.splitlines())
        except requests.RequestException as exc:
            log.warning("could not read %s (%s); continuing throttled", robots_url, exc)
            parser = None

        self._robots[root] = parser
        return parser

    def allowed(self, url: str) -> bool:
        if not self.obey_robots:
            return True
        parser = self._robots_for(url)
        if parser is None:
            return True
        return parser.can_fetch(self.user_agent, url)

    def crawl_delay(self, url: str) -> float | None:
        parser = self._robots_for(url) if self.obey_robots else None
        if parser is None:
            return None
        try:
            value = parser.crawl_delay(self.user_agent)
        except Exception:  # pragma: no cover - parser quirks across versions
            return None
        return float(value) if value else None

    # -- fetching ---------------------------------------------------------

    def get(self, url: str, **kwargs) -> requests.Response:
        if not self.allowed(url):
            raise RobotsDisallowed(f"robots.txt disallows {url}")

        site_delay = self.crawl_delay(url)
        if site_delay and site_delay > self.limiter.delay:
            log.info("honouring crawl-delay of %ss for %s", site_delay, url)
            self.limiter.delay = site_delay

        self.limiter.wait()
        kwargs.setdefault("timeout", self.timeout)
        log.debug("GET %s", url)
        resp = self.session.get(url, **kwargs)
        resp.raise_for_status()
        return resp

    def post(self, url: str, **kwargs) -> requests.Response:
        self.limiter.wait()
        kwargs.setdefault("timeout", self.timeout)
        resp = self.session.post(url, **kwargs)
        resp.raise_for_status()
        return resp

    def close(self) -> None:
        self.session.close()

    def __enter__(self) -> "PoliteSession":
        return self

    def __exit__(self, *exc) -> None:
        self.close()
