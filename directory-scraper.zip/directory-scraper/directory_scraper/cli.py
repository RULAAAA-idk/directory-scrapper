"""Command-line entry point.

    python -m directory_scraper --adapter overpass \
        --location "Austin, TX" --category cafe --limit 300 --out leads/austin-cafes
"""

from __future__ import annotations

import argparse
import logging
import sys

import requests

from .adapters import REGISTRY, SearchSpec, get_adapter
from .export import write_all
from .http import DEFAULT_USER_AGENT, PoliteSession
from .normalize import pipeline


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="directory-scraper",
        description="Scrape a business directory into a clean leads spreadsheet.",
    )
    parser.add_argument(
        "--adapter", default="overpass", choices=sorted(REGISTRY),
        help="which source to pull from (default: overpass)",
    )
    parser.add_argument("--location", default="", help='e.g. "Austin, TX"')
    parser.add_argument("--category", default="", help='e.g. cafe, or shop=florist')
    parser.add_argument("--limit", type=int, default=250, help="max records")
    parser.add_argument(
        "--radius", type=int, default=10_000,
        help="search radius in metres, for geo adapters (default: 10000)",
    )
    parser.add_argument(
        "--config", help="YAML site config, required by the html adapter",
    )
    parser.add_argument(
        "--out", default="output/leads",
        help="output path without extension; .csv and .xlsx are both written",
    )
    parser.add_argument(
        "--country-code", default="1",
        help="default calling code for local-format phone numbers (default: 1)",
    )
    parser.add_argument("--delay", type=float, default=1.5, help="seconds between requests")
    parser.add_argument("--user-agent", default=DEFAULT_USER_AGENT)
    parser.add_argument(
        "--ignore-robots", action="store_true",
        help="skip robots.txt checks. Only for sites you own or are licensed to crawl.",
    )
    parser.add_argument("-v", "--verbose", action="store_true")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(levelname)s %(message)s",
    )
    log = logging.getLogger("directory-scraper")

    if args.adapter == "html" and not args.config:
        log.error("the html adapter needs --config pointing at a YAML site config")
        return 2

    spec = SearchSpec(
        location=args.location,
        category=args.category,
        limit=args.limit,
        radius_m=args.radius,
        options={"config": args.config} if args.config else {},
    )

    adapter_cls = get_adapter(args.adapter)
    with PoliteSession(
        user_agent=args.user_agent,
        delay=args.delay,
        obey_robots=not args.ignore_robots,
    ) as session:
        try:
            raw = adapter_cls(session, spec).run()
        except ValueError as exc:
            log.error("%s", exc)
            return 2
        except requests.HTTPError as exc:
            status = exc.response.status_code if exc.response is not None else "?"
            log.error("the source returned HTTP %s: %s", status, exc.request.url if exc.request else "")
            if status in (403, 429):
                log.error(
                    "That usually means the User-Agent is missing real contact "
                    "details, or you are going too fast. Set --user-agent with "
                    "your project URL and email, and raise --delay."
                )
            return 1
        except requests.RequestException as exc:
            log.error("network error: %s", exc)
            return 1

    log.info("scraped %d raw records", len(raw))
    records = pipeline(raw, default_country=args.country_code)
    log.info("%d after cleaning and dedupe", len(records))

    if not records:
        log.warning("nothing to write — check the location, category or selectors")
        return 1

    for path in write_all(records, args.out):
        log.info("wrote %s", path)
    return 0


if __name__ == "__main__":
    sys.exit(main())
