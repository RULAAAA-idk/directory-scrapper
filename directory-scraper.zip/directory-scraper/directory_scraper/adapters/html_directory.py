"""Config-driven HTML directory adapter.

Most directory sites are the same shape: a paginated list of cards, each
card holding a few fields, sometimes with a detail page behind a link.
Rather than writing a new scraper per client, describe the site in YAML
and point this adapter at it.

See configs/example_directory.yml for the schema.
"""

from __future__ import annotations

import logging
from collections.abc import Iterator
from pathlib import Path
from typing import Any
from urllib.parse import urljoin

import yaml
from bs4 import BeautifulSoup

from ..http import RobotsDisallowed
from ..models import Business
from .base import Adapter

log = logging.getLogger(__name__)

# Which Business attribute each config key maps to.
FIELD_KEYS = (
    "name", "category", "street", "city", "state", "postcode", "country",
    "phone", "email", "website", "rating", "review_count",
)


def load_config(path: str | Path) -> dict[str, Any]:
    with Path(path).open(encoding="utf-8") as fh:
        config = yaml.safe_load(fh) or {}
    missing = [k for k in ("start_url", "item_selector") if k not in config]
    if missing:
        raise ValueError(f"config is missing required keys: {', '.join(missing)}")
    return config


def extract(node, rule: Any, base_url: str) -> str:
    """Pull one field out of a card.

    A rule is either a CSS selector string, or a dict:
        selector: ".phone"
        attr: href          # read an attribute instead of the text
        strip_prefix: "tel:"
        index: 0            # which match to take, default first
    """
    if not rule:
        return ""
    if isinstance(rule, str):
        rule = {"selector": rule}

    matches = node.select(rule["selector"])
    if not matches:
        return ""
    target = matches[min(rule.get("index", 0), len(matches) - 1)]

    attr = rule.get("attr")
    value = target.get(attr, "") if attr else target.get_text(" ", strip=True)
    if attr in ("href", "src") and value:
        value = urljoin(base_url, value)

    prefix = rule.get("strip_prefix")
    if prefix and value.startswith(prefix):
        value = value[len(prefix):]
    return value.strip()


class HtmlDirectoryAdapter(Adapter):
    name = "html"
    description = "Generic paginated HTML directory, described by a YAML config"

    def __init__(self, session, spec) -> None:
        super().__init__(session, spec)
        config_path = spec.options.get("config")
        if not config_path:
            raise ValueError("the html adapter needs options['config'] (a YAML path)")
        self.config = load_config(config_path)
        self.base_url = self.config.get("base_url") or self.config["start_url"]

    # -- urls -------------------------------------------------------------

    def page_urls(self) -> Iterator[str]:
        """Yield listing page URLs, one page at a time."""
        template = self.config["start_url"]
        fields = {
            "location": self.spec.location,
            "category": self.spec.category,
            "query": self.spec.options.get("query", self.spec.category),
        }

        pagination = self.config.get("pagination") or {}
        if not pagination:
            yield template.format(page=1, **fields)
            return

        start = int(pagination.get("start", 1))
        step = int(pagination.get("step", 1))
        max_pages = int(pagination.get("max_pages", 20))
        for i in range(max_pages):
            yield template.format(page=start + i * step, **fields)

    # -- parsing ----------------------------------------------------------

    def parse_card(self, card, page_url: str) -> Business:
        fields = self.config.get("fields", {})
        biz = Business(source=self.config.get("source_name", self.name), source_url=page_url)
        for key in FIELD_KEYS:
            if key in fields:
                setattr(biz, key, extract(card, fields[key], page_url))

        for key, rule in (self.config.get("extra_fields") or {}).items():
            biz.extra[key] = extract(card, rule, page_url)

        detail_rule = self.config.get("detail_link")
        if detail_rule:
            link = extract(card, detail_rule, page_url)
            if link:
                biz.source_url = link
                self.enrich_from_detail(biz, link)
        return biz

    def enrich_from_detail(self, biz: Business, url: str) -> None:
        """Open the business's own page to fill in fields the card omitted."""
        rules = self.config.get("detail_fields") or {}
        if not rules:
            return
        try:
            resp = self.session.get(url)
        except (RobotsDisallowed, Exception) as exc:  # noqa: BLE001
            log.warning("detail page %s failed: %s", url, exc)
            return

        soup = BeautifulSoup(resp.text, "lxml")
        for key, rule in rules.items():
            value = extract(soup, rule, url)
            if not value:
                continue
            if key in FIELD_KEYS:
                if not getattr(biz, key):
                    setattr(biz, key, value)
            else:
                biz.extra.setdefault(key, value)

    # -- main loop --------------------------------------------------------

    def fetch(self) -> Iterator[Business]:
        seen_pages = 0
        for url in self.page_urls():
            try:
                resp = self.session.get(url)
            except RobotsDisallowed:
                log.error("robots.txt blocks %s — stopping", url)
                return
            except Exception as exc:  # noqa: BLE001
                log.warning("page %s failed: %s", url, exc)
                continue

            soup = BeautifulSoup(resp.text, "lxml")
            cards = soup.select(self.config["item_selector"])
            log.info("%s -> %d cards", url, len(cards))

            if not cards:
                # Empty page means we've run past the end of the results.
                if seen_pages:
                    return
                continue

            seen_pages += 1
            for card in cards:
                yield self.parse_card(card, url)
