"""OpenStreetMap / Overpass adapter.

This is the demo source the README points at, for three reasons:

1. It is open data (ODbL), so the repo ships something anyone can run
   without a terms-of-service argument.
2. It carries the exact fields a lead list needs — name, address, phone,
   website, opening hours.
3. The API is public and free, so a reviewer can clone the repo and get
   real rows out of it in thirty seconds.

Category is an OSM tag: `amenity=cafe`, `shop=bakery`, `office=lawyer`.
See https://wiki.openstreetmap.org/wiki/Map_features for the full list.
"""

from __future__ import annotations

import logging
from collections.abc import Iterator

from ..models import Business
from .base import Adapter

log = logging.getLogger(__name__)

NOMINATIM_URL = "https://nominatim.openstreetmap.org/search"
OVERPASS_URL = "https://overpass-api.de/api/interpreter"

ALIASES = {
    "cafe": "amenity=cafe",
    "coffee": "amenity=cafe",
    "restaurant": "amenity=restaurant",
    "bar": "amenity=bar",
    "bakery": "shop=bakery",
    "hotel": "tourism=hotel",
    "dentist": "amenity=dentist",
    "doctor": "amenity=doctors",
    "pharmacy": "amenity=pharmacy",
    "gym": "leisure=fitness_centre",
    "salon": "shop=hairdresser",
    "hairdresser": "shop=hairdresser",
    "lawyer": "office=lawyer",
    "accountant": "office=accountant",
    "estate agent": "office=estate_agent",
    "car repair": "shop=car_repair",
    "plumber": "craft=plumber",
    "electrician": "craft=electrician",
    "school": "amenity=school",
    "veterinary": "amenity=veterinary",
}


def resolve_tag(category: str) -> tuple[str, str]:
    """Turn a human category into an OSM key/value pair."""
    category = (category or "").strip().lower()
    if "=" in category:
        key, _, value = category.partition("=")
        return key.strip(), value.strip()
    if category in ALIASES:
        key, _, value = ALIASES[category].partition("=")
        return key, value
    raise ValueError(
        f"don't know the OSM tag for {category!r}. "
        f"Pass one directly like 'shop=florist', or use one of: "
        f"{', '.join(sorted(ALIASES))}"
    )


class OverpassAdapter(Adapter):
    name = "overpass"
    description = "OpenStreetMap business data via the Overpass API (ODbL)"

    def geocode(self, location: str) -> tuple[float, float]:
        resp = self.session.get(
            NOMINATIM_URL,
            params={"q": location, "format": "json", "limit": 1},
        )
        results = resp.json()
        if not results:
            raise ValueError(f"could not geocode {location!r}")
        hit = results[0]
        log.info("resolved %r to %s", location, hit.get("display_name", ""))
        return float(hit["lat"]), float(hit["lon"])

    def build_query(self, lat: float, lon: float, key: str, value: str) -> str:
        radius = self.spec.radius_m
        around = f"around:{radius},{lat},{lon}"
        return (
            f"[out:json][timeout:90];\n"
            f"(\n"
            f'  node["{key}"="{value}"]({around});\n'
            f'  way["{key}"="{value}"]({around});\n'
            f'  relation["{key}"="{value}"]({around});\n'
            f");\n"
            f"out center tags {self.spec.limit};"
        )

    def fetch(self) -> Iterator[Business]:
        key, value = resolve_tag(self.spec.category)
        lat, lon = self.geocode(self.spec.location)
        query = self.build_query(lat, lon, key, value)

        resp = self.session.post(OVERPASS_URL, data={"data": query})
        elements = resp.json().get("elements", [])
        log.info("overpass returned %d elements", len(elements))

        for element in elements:
            tags = element.get("tags", {})
            if not tags.get("name"):
                continue

            lat_val = element.get("lat") or element.get("center", {}).get("lat", "")
            lon_val = element.get("lon") or element.get("center", {}).get("lon", "")
            osm_id = f"{element.get('type', 'node')}/{element.get('id', '')}"

            yield Business(
                name=tags.get("name", ""),
                category=f"{key}={value}",
                street=" ".join(
                    p for p in (tags.get("addr:housenumber"), tags.get("addr:street")) if p
                ),
                city=tags.get("addr:city", ""),
                state=tags.get("addr:state", ""),
                postcode=tags.get("addr:postcode", ""),
                country=tags.get("addr:country", ""),
                phone=tags.get("phone") or tags.get("contact:phone", ""),
                email=tags.get("email") or tags.get("contact:email", ""),
                website=tags.get("website") or tags.get("contact:website", ""),
                latitude=str(lat_val),
                longitude=str(lon_val),
                source="openstreetmap",
                source_url=f"https://www.openstreetmap.org/{osm_id}",
                extra={
                    "opening_hours": tags.get("opening_hours", ""),
                    "cuisine": tags.get("cuisine", ""),
                },
            )
