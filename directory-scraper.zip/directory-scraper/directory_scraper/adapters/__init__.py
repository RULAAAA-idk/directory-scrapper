"""Adapter registry.

An adapter knows how to turn a search (location + category) into Business
records from one source. Add a new file, register it here, and the CLI
picks it up.
"""

from __future__ import annotations

from .base import Adapter, SearchSpec
from .html_directory import HtmlDirectoryAdapter
from .overpass import OverpassAdapter

REGISTRY: dict[str, type[Adapter]] = {
    OverpassAdapter.name: OverpassAdapter,
    HtmlDirectoryAdapter.name: HtmlDirectoryAdapter,
}


def get_adapter(name: str) -> type[Adapter]:
    try:
        return REGISTRY[name]
    except KeyError:
        known = ", ".join(sorted(REGISTRY))
        raise KeyError(f"unknown adapter {name!r}; available: {known}") from None


__all__ = ["Adapter", "SearchSpec", "REGISTRY", "get_adapter"]
