"""Base adapter interface."""

from __future__ import annotations

from collections.abc import Iterator
from dataclasses import dataclass, field
from typing import Any

from ..http import PoliteSession
from ..models import Business


@dataclass
class SearchSpec:
    """What the buyer asked for, in one object."""

    location: str = ""
    category: str = ""
    limit: int = 250
    radius_m: int = 10_000
    options: dict[str, Any] = field(default_factory=dict)


class Adapter:
    """Subclass this to add a source.

    Only `fetch` is required. Yield Business objects as you find them —
    the pipeline cleans and dedupes afterwards, so adapters should stay
    dumb and just report what the page said.
    """

    name: str = "base"
    description: str = ""

    def __init__(self, session: PoliteSession, spec: SearchSpec) -> None:
        self.session = session
        self.spec = spec

    def fetch(self) -> Iterator[Business]:  # pragma: no cover - interface
        raise NotImplementedError

    def run(self) -> list[Business]:
        out: list[Business] = []
        for biz in self.fetch():
            biz.source = biz.source or self.name
            out.append(biz)
            if len(out) >= self.spec.limit:
                break
        return out
