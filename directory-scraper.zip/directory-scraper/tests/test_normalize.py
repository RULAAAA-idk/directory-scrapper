"""Tests for the cleaning layer — the part that actually earns the money."""

from directory_scraper.models import Business
from directory_scraper.normalize import (
    clean_email,
    clean_phone,
    clean_website,
    dedupe,
    pipeline,
    squash,
)


def test_squash_collapses_whitespace_and_unicode():
    assert squash("  Joe's   Cafe\n") == "Joe's Cafe"
    assert squash(None) == ""


def test_clean_phone_handles_common_us_formats():
    assert clean_phone("(512) 555-0134") == "+15125550134"
    assert clean_phone("512.555.0134") == "+15125550134"
    assert clean_phone("1-512-555-0134") == "+15125550134"
    assert clean_phone("+44 20 7946 0958") == "+442079460958"


def test_clean_phone_respects_default_country():
    assert clean_phone("98470 12345", default_country="91") == "+919847012345"


def test_clean_phone_keeps_unparseable_input():
    assert clean_phone("call us!") == ""
    # Too few digits to be a real number: hand the original back rather than
    # inventing a country code for it.
    assert clean_phone("ext. 4") == "ext. 4"


def test_clean_email_extracts_from_noise():
    assert clean_email("Email: Sales@Example.COM ") == "sales@example.com"
    assert clean_email("no address here") == ""


def test_clean_website_adds_scheme_and_drops_tracking():
    assert clean_website("example.com/shop/") == "https://example.com/shop"
    assert clean_website("https://a.com/x?utm_source=g&id=5") == "https://a.com/x?id=5"
    assert clean_website("https://a.com/x?utm_source=g") == "https://a.com/x"


def test_dedupe_merges_on_shared_phone():
    records = [
        Business(name="Joe's Cafe", phone="+15125550134"),
        Business(name="Joes Cafe", phone="+15125550134", website="https://joes.com"),
    ]
    out = dedupe(records)
    assert len(out) == 1
    assert out[0].website == "https://joes.com"


def test_dedupe_keeps_distinct_businesses():
    records = [
        Business(name="Joe's Cafe", city="Austin", phone="+15125550134"),
        Business(name="Ann's Bakery", city="Austin", phone="+15125550999"),
    ]
    assert len(dedupe(records)) == 2


def test_pipeline_drops_nameless_rows_and_normalises():
    records = [
        Business(name="  Joe's   Cafe ", phone="(512) 555-0134"),
        Business(name="", phone="(512) 555-0999"),
    ]
    out = pipeline(records)
    assert len(out) == 1
    assert out[0].name == "Joe's Cafe"
    assert out[0].phone == "+15125550134"
